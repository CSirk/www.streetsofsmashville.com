Left click clipflow tray icon : add clipboard text to clipflow menu (if there is text in clipboard)
Right click clipflow tray icon : show clipflow clipboard menu
	- click mouse : add item to clipboard
	- click mouse + ctrl : remove item
	- click mouse + shift : Exit ClipFlow